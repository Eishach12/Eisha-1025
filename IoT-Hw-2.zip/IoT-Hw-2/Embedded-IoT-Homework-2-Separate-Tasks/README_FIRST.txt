# Embedded IoT Homework 2 — Separate Task Files

This ZIP contains two clearly separated task folders, both under one homework package:

1. `Task-1-Dual-LED-PWM` — Task 1 only: two LEDs fading independently at 1 kHz and 5 kHz.
2. `Task-2-OLED-Monitoring` — final combined project: the same two LED PWM outputs plus SSD1306 OLED monitoring.

The assignment asks for one project and two GitHub commits. Treat Task 1 as the first-stage snapshot and Task 2 as the final combined version. In your existing course repository, preserve the required commit order:
- First: `task1 completed`
- Second: `complete homework`

Each task folder includes its own `src/main.cpp`, `diagram.json`, `platformio.ini`, `wokwi.toml`, and README.

**Not included:** real Wokwi screenshots, a Wokwi share URL, physical hardware photographs, or verified test results. These must come from your own simulation and hardware kit.
