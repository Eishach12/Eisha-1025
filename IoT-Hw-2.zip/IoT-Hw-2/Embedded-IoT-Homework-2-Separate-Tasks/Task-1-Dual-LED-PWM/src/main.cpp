#include <Arduino.h>

// ESP32 DevKit V1: two independent PWM LED outputs.
constexpr uint8_t LED1_PIN = 18;
constexpr uint8_t LED2_PIN = 19;

constexpr uint32_t LED1_FREQUENCY = 1000; // 1 kHz
constexpr uint32_t LED2_FREQUENCY = 5000; // 5 kHz
constexpr uint8_t PWM_RESOLUTION = 8;     // duty range 0..255
constexpr uint16_t PWM_MAX_DUTY = 255;

// Original ESP32: channels 0-7 and 8-15 are in separate LEDC groups.
constexpr uint8_t LED1_CHANNEL = 0;
constexpr uint8_t LED2_CHANNEL = 8;

uint16_t duty1 = 0;
uint16_t duty2 = 0;
int8_t direction1 = 1;
int8_t direction2 = 1;
unsigned long previous1 = 0;
unsigned long previous2 = 0;

constexpr uint8_t DUTY_STEP = 2;
constexpr unsigned long LED1_INTERVAL_MS = 12;
constexpr unsigned long LED2_INTERVAL_MS = 7;

void writePwm(uint8_t pin, uint8_t channel, uint16_t duty) {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  (void)channel;
  ledcWrite(pin, duty);       // Arduino-ESP32 core 3.x uses the pin
#else
  (void)pin;
  ledcWrite(channel, duty);   // Arduino-ESP32 core 2.x uses the channel
#endif
}

bool configurePwm() {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  bool first = ledcAttachChannel(LED1_PIN, LED1_FREQUENCY,
                                 PWM_RESOLUTION, LED1_CHANNEL);
  bool second = ledcAttachChannel(LED2_PIN, LED2_FREQUENCY,
                                  PWM_RESOLUTION, LED2_CHANNEL);
  return first && second;
#else
  bool first = ledcSetup(LED1_CHANNEL, LED1_FREQUENCY,
                         PWM_RESOLUTION) > 0;
  bool second = ledcSetup(LED2_CHANNEL, LED2_FREQUENCY,
                          PWM_RESOLUTION) > 0;
  ledcAttachPin(LED1_PIN, LED1_CHANNEL);
  ledcAttachPin(LED2_PIN, LED2_CHANNEL);
  return first && second;
#endif
}

void changeDuty(uint16_t &duty, int8_t &direction) {
  int16_t next = static_cast<int16_t>(duty) +
                 direction * static_cast<int16_t>(DUTY_STEP);

  if (next >= PWM_MAX_DUTY) {
    next = PWM_MAX_DUTY;
    direction = -1;
  } else if (next <= 0) {
    next = 0;
    direction = 1;
  }
  duty = static_cast<uint16_t>(next);
}

void setup() {
  Serial.begin(115200);

  if (!configurePwm()) {
    Serial.println("PWM configuration failed. Check ESP32 board/core.");
    while (true) delay(1000);
  }

  writePwm(LED1_PIN, LED1_CHANNEL, 0);
  writePwm(LED2_PIN, LED2_CHANNEL, 0);

  Serial.println("Task 1: Dual LED PWM fading started.");
  Serial.println("LED1: GPIO18, 1000 Hz; LED2: GPIO19, 5000 Hz.");
}

void loop() {
  unsigned long now = millis();

  if (now - previous1 >= LED1_INTERVAL_MS) {
    previous1 = now;
    changeDuty(duty1, direction1);
    writePwm(LED1_PIN, LED1_CHANNEL, duty1);
  }

  if (now - previous2 >= LED2_INTERVAL_MS) {
    previous2 = now;
    changeDuty(duty2, direction2);
    writePwm(LED2_PIN, LED2_CHANNEL, duty2);
  }
}
