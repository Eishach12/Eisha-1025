#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ---------------- Pins ----------------
constexpr uint8_t LED1_PIN = 18;
constexpr uint8_t LED2_PIN = 19;
constexpr uint8_t OLED_SDA = 21;
constexpr uint8_t OLED_SCL = 22;
constexpr uint8_t OLED_ADDRESS = 0x3C;
constexpr uint8_t SCREEN_WIDTH = 128;
constexpr uint8_t SCREEN_HEIGHT = 64;

// ---------------- PWM settings ----------------
constexpr uint32_t LED1_FREQUENCY = 1000; // 1 kHz
constexpr uint32_t LED2_FREQUENCY = 5000; // 5 kHz
constexpr uint8_t PWM_RESOLUTION = 8;
constexpr uint16_t PWM_MAX_DUTY = 255;

// Original ESP32: separate LEDC groups allow separate frequency settings.
constexpr uint8_t LED1_CHANNEL = 0;
constexpr uint8_t LED2_CHANNEL = 8;

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

uint16_t duty1 = 0;
uint16_t duty2 = 0;
int8_t direction1 = 1;
int8_t direction2 = 1;
unsigned long previous1 = 0;
unsigned long previous2 = 0;
unsigned long previousDisplay = 0;

constexpr uint8_t DUTY_STEP = 2;
constexpr unsigned long LED1_INTERVAL_MS = 12;
constexpr unsigned long LED2_INTERVAL_MS = 7;
constexpr unsigned long DISPLAY_INTERVAL_MS = 200;

void writePwm(uint8_t pin, uint8_t channel, uint16_t duty) {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  (void)channel;
  ledcWrite(pin, duty);
#else
  (void)pin;
  ledcWrite(channel, duty);
#endif
}

bool configurePwm() {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  bool first = ledcAttachChannel(LED1_PIN, LED1_FREQUENCY,
                                 PWM_RESOLUTION, LED1_CHANNEL);
  bool second = ledcAttachChannel(LED2_PIN, LED2_FREQUENCY,
                                  PWM_RESOLUTION, LED2_CHANNEL);
  return first && second;
#else
  bool first = ledcSetup(LED1_CHANNEL, LED1_FREQUENCY,
                         PWM_RESOLUTION) > 0;
  bool second = ledcSetup(LED2_CHANNEL, LED2_FREQUENCY,
                          PWM_RESOLUTION) > 0;
  ledcAttachPin(LED1_PIN, LED1_CHANNEL);
  ledcAttachPin(LED2_PIN, LED2_CHANNEL);
  return first && second;
#endif
}

void changeDuty(uint16_t &duty, int8_t &direction) {
  int16_t next = static_cast<int16_t>(duty) +
                 direction * static_cast<int16_t>(DUTY_STEP);
  if (next >= PWM_MAX_DUTY) {
    next = PWM_MAX_DUTY;
    direction = -1;
  } else if (next <= 0) {
    next = 0;
    direction = 1;
  }
  duty = static_cast<uint16_t>(next);
}

void updateOled() {
  uint8_t percent1 = static_cast<uint8_t>(duty1 * 100U / PWM_MAX_DUTY);
  uint8_t percent2 = static_cast<uint8_t>(duty2 * 100U / PWM_MAX_DUTY);

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);

  display.setCursor(0, 0);
  display.println("DUAL PWM MONITOR");
  display.println("----------------");

  display.setCursor(0, 22);
  display.print("LED1: ");
  display.print(percent1);
  display.print("% F:");
  display.print(LED1_FREQUENCY);
  display.println("Hz");

  display.setCursor(0, 40);
  display.print("LED2: ");
  display.print(percent2);
  display.print("% F:");
  display.print(LED2_FREQUENCY);
  display.println("Hz");

  display.display();
}

void setup() {
  Serial.begin(115200);
  Wire.begin(OLED_SDA, OLED_SCL);

  if (!configurePwm()) {
    Serial.println("PWM configuration failed.");
    while (true) delay(1000);
  }

  writePwm(LED1_PIN, LED1_CHANNEL, 0);
  writePwm(LED2_PIN, LED2_CHANNEL, 0);

  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDRESS)) {
    Serial.println("SSD1306 not found. Check I2C wiring/address.");
    while (true) delay(1000);
  }

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("ESP32 PWM Project");
  display.println("OLED initialized");
  display.display();

  Serial.println("Task 2: Dual PWM with OLED started.");
  delay(800);
}

void loop() {
  unsigned long now = millis();

  if (now - previous1 >= LED1_INTERVAL_MS) {
    previous1 = now;
    changeDuty(duty1, direction1);
    writePwm(LED1_PIN, LED1_CHANNEL, duty1);
  }

  if (now - previous2 >= LED2_INTERVAL_MS) {
    previous2 = now;
    changeDuty(duty2, direction2);
    writePwm(LED2_PIN, LED2_CHANNEL, duty2);
  }

  if (now - previousDisplay >= DISPLAY_INTERVAL_MS) {
    previousDisplay = now;
    updateOled();
  }
}
