# Task 2 — OLED Monitoring (Final Combined Project)

This folder contains Task 1's two independent LED PWM outputs plus the SSD1306 OLED monitoring required by Task 2. It is the final combined version of the same project.

## Wiring (ESP32 DevKit V1)
- GPIO 18 -> separate 220 ohm resistor -> LED 1 anode (+); LED 1 cathode (-) -> GND.
- GPIO 19 -> separate 220 ohm resistor -> LED 2 anode (+); LED 2 cathode (-) -> GND.
- OLED VCC -> 3V3; OLED GND -> GND; OLED SDA -> GPIO 21; OLED SCL -> GPIO 22.
- OLED I2C address: 0x3C. Confirm the pin labels and voltage on the actual display.
- Each LED must have its own resistor.

## PWM settings
| LED | GPIO | LEDC channel | Frequency | Resolution |
|---|---:|---:|---:|---:|
| LED 1 | 18 | 0 | 1000 Hz (1 kHz) | 8 bit |
| LED 2 | 19 | 8 | 5000 Hz (5 kHz) | 8 bit |

Duty is swept from 0 to 255 and back. The percentage shown is calculated from the same duty value written to the PWM output: `duty * 100 / 255`. Higher duty means greater average power and greater apparent LED brightness. Frequency is the number of PWM cycles per second.

## OLED
The 128 x 64 SSD1306 display refreshes every 200 ms and shows both live duty percentages and the configured frequencies. The percentage values change continuously; the frequencies remain 1000 Hz and 5000 Hz.

## LEDC technical note
This project targets the original ESP32 DevKit V1. It assigns LED 1 to channel 0 and LED 2 to channel 8, which are in separate LEDC channel groups on the original ESP32. This is intended to keep their PWM frequency settings independent. Other ESP32 variants may differ. The code supports Arduino-ESP32 core 2.x and 3.x.

## Wokwi test
Open this folder as an ESP32 PlatformIO project, install the Adafruit GFX and Adafruit SSD1306 libraries if prompted, and run the simulation. Verify that both LEDs fade and the OLED updates. Save your own screenshots in `screenshots/`.

Wokwi project URL: **Add your own saved Wokwi share link here.**

## Physical hardware test
Build the circuit on the physical kit, upload the program, and verify both LEDs and OLED. Disconnect power before changing wiring. Take your own photographs and record actual results here: **To be completed after testing.**

## Wokwi vs hardware
Fill this comparison only after testing both:
| Check | Wokwi | Physical hardware |
|---|---|---|
| LED 1 fading | Record result | Record result |
| LED 2 fading | Record result | Record result |
| OLED live values | Record result | Record result |
| Observed differences | Record result | Record result |

## GitHub commit sequence
Use the same existing course repository. First commit the Task 1 files with exactly `task1 completed`. Then add the Task 2 OLED files/changes and commit with exactly `complete homework`. Verify the order in the repository history.
